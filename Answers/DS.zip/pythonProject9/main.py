from array import array


def rotate_array(arr, k):
    n = len(arr)
    # کم کردن k از n تا از حالتی جلوگیری کنیم که k بیشتر از طول آرایه باشد
    k = k % n
    # ایجاد یک آرایه جدید برای نتیجه
    rotated_arr = [0] * n

    # انتقال المان‌های آرایه به موقعیت جدید
    for i in range(n):
        new_index = (i + k) % n
        rotated_arr[new_index] = arr[i]

    return rotated_arr

arr= [1,2,3,4,5]
print(rotate_array(arr,2))