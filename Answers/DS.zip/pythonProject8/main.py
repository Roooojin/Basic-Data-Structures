import array

def Find_The_Missing_Number(array):
    n=len(array)+1
    for i in range(n):
        if array[i]!=i:
            return i
            break
    return None


array=[0,1,2,4]
print(Find_The_Missing_Number(array))
