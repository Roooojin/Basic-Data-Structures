class SparseMatrix:
    def __init__(self,matrix):
        self.rows = len(matrix)
        self.cols = len(matrix[0])
        self.sparse = []

        for i in range(self.rows):
            for j in range(self.cols):
                if matrix[i][j] != 0:
                    self.sparse.append((i, j, matrix[i][j]))

    def transpose(self):
        # Create a new sparse matrix to store the transposed matrix
        transposed = SparseMatrix([[0] * self.rows for _ in range(self.cols)])

        for i, j, val in self.sparse:
            transposed.sparse.append((j, i, val))

        return transposed

    def change_element(self, row, col, new_val):
        # Find the index of the element in the sparse matrix
        index = -1
        for i, (r, c, val) in enumerate(self.sparse):
            if r == row and c == col:
                index = i
                break

        if index != -1:
            # Update the value of the element
            self.sparse[index] = (row, col, new_val)
        else:
            # If the element is not found, add it to the sparse matrix
            self.sparse.append((row, col, new_val))

    def print_matrix(self):
        # Create a normal matrix based on the sparse representation
        matrix = [[0] * self.cols for _ in range(self.rows)]

        for i, j, val in self.sparse:
            matrix[i][j] = val

        # Print the matrix
        for row in matrix:
            print(row)



matrix = [
    [1, 2, 0],
    [0, 0, 3],
    [4, 0, 5]
]

sparse_matrix = SparseMatrix(matrix)

# Transpose the sparse matrix
transposed_matrix = sparse_matrix.transpose()
transposed_matrix.print_matrix()

# Change an element in the sparse matrix
sparse_matrix.change_element(1, 2, 6)
sparse_matrix.print_matrix()






