def remove_duplicates(array):
    count = 1
    for i in range(1, len(array)):
        if array[i - 1] != array[i]:
            array[count] = array[i]
            count += 1

    return array[:count], count

a = [1, 1, 2, 2, 3, 4, 5, 5]
new_array, length = remove_duplicates(a)
print(new_array)
print(length)