def max_subarray_sum(nums):
    max_sum = float('-inf')  # مجموع بیشینه را با یک عدد بسیار کوچک مقداردهی اولیه می‌کنیم
    current_sum = 0  # مجموع فعلی را با صفر مقداردهی اولیه می‌کنیم
    start = end = 0  # شروع و پایان زیرآرایهٔ متوالی با بیشترین مجموع

    for i, num in enumerate(nums):
        if current_sum + num < num:
            # شروع دنبالهٔ جدید از این عنصر
            current_sum = num
            start = i
        else:
            # ادامهٔ دنبالهٔ فعلی
            current_sum += num

        if current_sum > max_sum:
            # به‌روزرسانی مجموع بیشترین مجموع و پایان زیرآرایهٔ متوالی
            max_sum = current_sum
            end = i

    # بازسازی زیرآرایهٔ متوالی با بیشترین مجموع
    subarray = nums[start:end+1]

    return max_sum, subarray


nums = [-2, -1, -3, 4, -1, 2, 1, -5, 4]
max_sum, subarray = max_subarray_sum(nums)
print("Max Subarray Sum:", max_sum)
print("Subarray:", subarray)