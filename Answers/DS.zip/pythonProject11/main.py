def Merge(array1, array2):
    sortedArray = []
    i = 0
    j = 0

    while i < len(array1) and j < len(array2):
        if array1[i] > array2[j]:
            sortedArray.append(array2[j])
            j += 1
        else:
            sortedArray.append(array1[i])
            i += 1

    while i < len(array1):
        sortedArray.append(array1[i])
        i += 1

    while j < len(array2):
        sortedArray.append(array2[j])
        j += 1

    return sortedArray


num1 = [1, 2, 3]
num2 = [2, 5, 6]
print(Merge(num1, num2))